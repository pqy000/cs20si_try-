
//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeDotProduct.cpp

 HPCG routine
 */

#include "ComputeDotProduct.hpp"
#include "ComputeDotProduct_ref.hpp"

#include <cassert>

#ifndef HPCG_NOMPI
#include <mpi.h>
#include "mytimer.hpp"
#endif
#ifndef HPCG_NOOPENMP
#include <omp.h>
#endif

/*!
  Routine to compute the dot product of two vectors.

  This routine calls the reference dot-product implementation by default, but
  can be replaced by a custom routine that is optimized and better suited for
  the target system.

  @param[in]  n the number of vector elements (on this processor)
  @param[in]  x, y the input vectors
  @param[out] result a pointer to scalar value, on exit will contain the result.
  @param[out] time_allreduce the time it took to perform the communication between processes
  @param[out] isOptimized should be set to false if this routine uses the reference implementation (is not optimized); otherwise leave it unchanged

  @return returns 0 upon success and non-zero otherwise

  @see ComputeDotProduct_ref
*/
int ComputeDotProduct(const local_int_t n, const Vector & x, const Vector & y,
    double & result, double & time_allreduce, bool & isOptimized) {

  // This line and the next two lines should be removed and your version of ComputeDotProduct should be used.
  isOptimized = false;
  return(ComputeDotProduct_ref(n, x, y, result, time_allreduce));
}

int ComputeDotProductAllreduce(const local_int_t n, const Vector & r, const Vector & u, const Vector & w,
    double & gama, double & delta, double & normr, double & time_allreduce){

  double lgama = 0.0, ldelta = 0.0, lnormr = 0.0;
  double * rv = r.values;
  double * uv = u.values;
  double * wv = w.values;

#ifndef HPCG_NOOPENMP
  #pragma omp parallel for reduction (+:lgama,ldelta,lnormr)
#endif
    for (local_int_t i=0; i<n; i++){
      lnormr += rv[i]*rv[i];
      lgama += rv[i]*uv[i];
      ldelta += wv[i]*uv[i];
    }

#ifndef HPCG_NOMPI
  double local_result[3];
  double global_result[3] = {0.0};
 
  local_result[0] = lgama;
  local_result[1] = ldelta;
  local_result[2] = lnormr;

  double tr = mytimer();

  MPI_Allreduce(local_result, global_result, 3, MPI_DOUBLE, MPI_SUM,
      MPI_COMM_WORLD);

  time_allreduce += mytimer() - tr;

  gama = global_result[0];
  delta = global_result[1];
  normr = global_result[2];
#else
  gama = lgama;
  delta = ldelta;
  normr = lnormr;
#endif

  return(0);
}
