
//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeSPMV.cpp

 HPCG routine
 */

#include "ComputeSPMV.hpp"
#include "ComputeSPMV_ref.hpp"

#ifndef HPCG_NOMPI
#include "ExchangeHalo.hpp"
#endif

#ifndef HPCG_NOOPENMP
#include <omp.h>
#endif
#include <cassert>

#include "Geometry.hpp"

/*!
  Routine to compute sparse matrix vector product y = Ax where:
  Precondition: First call exchange_externals to get off-processor values of x

  This routine calls the reference SpMV implementation by default, but
  can be replaced by a custom, optimized routine suited for
  the target system.

  @param[in]  A the known system matrix
  @param[in]  x the known vector
  @param[out] y the On exit contains the result: Ax.

  @return returns 0 upon success and non-zero otherwise

  @see ComputeSPMV_ref
*/
int ComputeSPMV( const SparseMatrix & A, Vector & x, Vector & y) {

//  A.isSpmvOptimized = false;
//  return(ComputeSPMV_ref(A, x, y));

  assert(x.localLength>=A.localNumberOfColumns); // Test vector lengths
  assert(y.localLength>=A.localNumberOfRows);

//  double * const yv = y.values;
//  const local_int_t nrow = A.localNumberOfRows;
//
//#pragma omp parallel sections
//{
//  #pragma omp section
//  {
//    const double * const xv = x.values;
//    
//    #pragma omp parallel for
//      for(local_int_t i=0; i<nrow; i++){
//	if(ComputeRankOfMatrixRow(*(A.geom), i) == A.geom->rank){
//	  double sum = 0.0;
//	  const double * const cur_vals = A.matrixValues[i];
//          const local_int_t * const cur_inds = A.mtxIndL[i];
//	  const int cur_nnz = A.nonzerosInRow[i];
//
//	  for (int j=0; j<cur_nnz; j++)
//	    sum += cur_vals[j]*xv[cur_inds[j]];
//	  
//	  yv[i] = sum;
//	}
//      }
//  }
//
//  #pragma omp section
//  {
//    #ifndef HPCG_NOMPI
//      ExchangeHalo(A,x);
//    #endif
//
//    const double * const xv = x.values;
//
//    //#pragma omp parallel for
//      for(local_int_t i=0; i<nrow; i++){
//        if(ComputeRankOfMatrixRow(*(A.geom), i) != A.geom->rank){
//	  double sum = 0.0;
//	  const double * const cur_vals = A.matrixValues[i];
//          const local_int_t * const cur_inds = A.mtxIndL[i];
//          const int cur_nnz = A.nonzerosInRow[i];
//
//          for (int j=0; j<cur_nnz; j++)
//            sum += cur_vals[j]*xv[cur_inds[j]];
//
//          yv[i] = sum;
//	}
//      }
//  }
//}


#ifndef HPCG_NOMPI
    ExchangeHalo(A,x);
#endif
  const double * const xv = x.values;
  double * const yv = y.values;
  const local_int_t nrow = A.localNumberOfRows;
#ifndef HPCG_NOOPENMP
  #pragma omp parallel for
#endif
  for (local_int_t i=0; i< nrow; i++)  {
    double sum = 0.0;
    const double * const cur_vals = A.matrixValues[i];
    const local_int_t * const cur_inds = A.mtxIndL[i];
    const int cur_nnz = A.nonzerosInRow[i];

    for (int j=0; j< cur_nnz; j++)
      sum += cur_vals[j]*xv[cur_inds[j]];
    yv[i] = sum;
  }


//#ifndef HPCG_NOMPI
//    ExchangeHalo(A,x);
//#endif
//
//const double * const xv = x.values;
//double * const yv = y.values;
//const local_int_t nrow = A.localNumberOfRows;
////double * mtxValues = A.mtxValues;
////local_int_t * mtxIndices = A.mtxIndices;
//
////#pragma offload_transfer target(mic:0) in(xv:length(nrow) alloc_if(1) free_if(0))// signal(xv)
//
//#ifndef HPCG_NOOPENMP
//  #pragma omp parallel for
//#endif
//  for (local_int_t i=0; i<nrow; i++)  {
//    double sum = 0.0;
//    const double * const cur_vals = A.matrixValues[i];
//    const local_int_t * const cur_inds = A.mtxIndL[i];
//    //const double * const cur_vals = A.mtxValues + i*27;
//    //const local_int_t * const cur_inds = A.mtxIndices + i*27;
//    const int cur_nnz = A.nonzerosInRow[i];
//
//    //#pragma offload target(mic:0) in(cur_vals:length(cur_nnz) alloc_if(1) free_if(1)) in(cur_inds:length(cur_nnz) alloc_if(1) free_if(1)) nocopy(xv:length(nrow) alloc_if(0) free_if(0))// wait(xv)
//    //{
//      //#pragma vector aligned
//      //#pragma simd reduction(+:val) reduction(+:val2)
//      //#pragma unroll(4)
//      for (int j=0; j<cur_nnz; j++)
//        sum += cur_vals[j]*xv[cur_inds[j]];
//    //}
//
//    yv[i] = sum;
//  }

  return(0);
}
